function AllRoutes() {
  return <div>{/* Add Home, Login and dashboard  */}</div>;
}

export default AllRoutes;
