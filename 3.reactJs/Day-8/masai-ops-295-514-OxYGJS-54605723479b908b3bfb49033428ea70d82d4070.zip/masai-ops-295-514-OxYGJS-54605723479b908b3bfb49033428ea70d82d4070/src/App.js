import "./App.css";

function App() {
  return <div>{/* add MObileOs component here */}</div>;
}

export default App;
