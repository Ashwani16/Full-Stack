function AllRoutes() {
  return (
    <div>

    </div>
  );
}

export default AllRoutes;
