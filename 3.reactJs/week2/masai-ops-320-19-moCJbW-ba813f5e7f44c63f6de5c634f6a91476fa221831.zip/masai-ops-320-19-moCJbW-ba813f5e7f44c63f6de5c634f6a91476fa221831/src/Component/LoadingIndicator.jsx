function LoadingIndicator() {
  return <div data-testid="loading-indicator">...Loading</div>;
}

export default LoadingIndicator;
