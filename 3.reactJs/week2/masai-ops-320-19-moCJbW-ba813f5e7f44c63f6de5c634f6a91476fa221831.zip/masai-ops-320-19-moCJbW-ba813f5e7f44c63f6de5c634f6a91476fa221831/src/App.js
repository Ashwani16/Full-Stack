import Countries from "./Component/Countries";
import "./App.css";

export default function App() {
  return (
    <div className="App">
      <Countries />
    </div>
  );
}
