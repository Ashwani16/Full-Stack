//DO NOT CHANGE THE STRUCTURE OF THIS INITIAL STATE;
const initialState = {
    data: [],
    isLoading: false,
    isError: false,
  };
  
  export { initialState };
  