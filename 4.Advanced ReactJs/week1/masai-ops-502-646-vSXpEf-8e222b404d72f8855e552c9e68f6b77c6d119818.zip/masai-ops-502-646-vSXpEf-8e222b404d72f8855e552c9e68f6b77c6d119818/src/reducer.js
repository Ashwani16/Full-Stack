//import the action types here from the actionTypes.js to be used in the reducer function

//Complete the reducer function here
const reducer = () => {};

export { reducer };
