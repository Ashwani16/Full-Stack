import React from "react";

// get the product item details through the props
const ProductCard = () => {
  return <div data-testid="productcard"></div>;
};

export default ProductCard;
